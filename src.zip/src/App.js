import { BrowserRouter } from "react-router-dom";
import RouteApp from "./services/routes";
import SideBar from "./Components/SideBar/SideBar";
import Header from "./Components/Header/header";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Header></Header>
        <SideBar />
        <RouteApp></RouteApp>
      </BrowserRouter>
    </div>
  );
}

export default App;

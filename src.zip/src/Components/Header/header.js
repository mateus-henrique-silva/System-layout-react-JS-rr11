import React from "react";
import { MdMenu } from "react-icons/md";
import "./Styles.css";

const header = () => {
  return (
    <div>
      <div id="header">
        <div>
          <button id="btn-menu">
            <MdMenu size={30} color="black"></MdMenu>
          </button>
        </div>

        <div>header</div>
      </div>
    </div>
  );
};

export default header;

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

import "./SideBar.css";

const SideBar = () => {
  const [modalSideBar, setModalSideBar] = useState(true);
  function hiddenSide() {
    setModalSideBar(false);
  }
  return (
    <div>
      {modalSideBar != false ? (
        <aside>
          <div>
            <h1>SideBar</h1>
            <button onClick={hiddenSide}>return</button>
          </div>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/login">Login</Link>
            </li>
            <li>
              <Link to="/adminCr">Cadastro</Link>
            </li>
            <li>
              <Link to="/productsList">Lista de produtos</Link>
            </li>
          </ul>
          <footer>Footer</footer>
        </aside>
      ) : (
        ""
      )}
    </div>
  );
};

export default SideBar;

export default function hiddenSide() {
  setModalSideBar(false);
}

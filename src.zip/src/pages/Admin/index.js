import React from "react";
import SideBar from "../../Components/SideBar/SideBar";

const index = () => {
  return (
    <div>
      <SideBar />
    </div>
  );
};

export default index;



export default function Cadastro() {
    return (
        <div>
           <h1>Cadastro</h1>
        </div>
    )
}
import { Switch, Route } from "react-router-dom";

import Home from "../pages/Home";
import Cadastro from "../pages/Cadastro";
import Login from "../pages/Login";
import Admin from "../pages/Admin";
import AdminCadastro from "../pages/AdminCadastro";
import ListProducts from "../pages/ProductsList";

export default function RouteApp() {
  return (
    <Switch>
      <Route exact path={"/"} component={Home}></Route>
      <Route exact path={"/cadastro"} component={Cadastro}></Route>
      <Route exact path={"/login"} component={Login}></Route>
      <Route exact path={"/admin"} component={Admin}></Route>
      <Route exact path={"/adminCr"} component={AdminCadastro}></Route>
      <Route exact path={"/productsList"} component={ListProducts}></Route>
      <Route exact path={"/productsList:_id"} component={ListProducts}></Route>
    </Switch>
  );
}
